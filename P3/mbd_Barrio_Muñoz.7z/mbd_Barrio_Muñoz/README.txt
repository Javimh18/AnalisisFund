No hemos sido capaces de exportar el PDF sin el código por mas que lo hemos intentado.
Disculpa las molestias.

